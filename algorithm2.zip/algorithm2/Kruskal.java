package A2;

import java.util.*;

public class Kruskal {

    public static WGraph kruskal(WGraph g) {

        /* Fill this method (The statement return null is here only to compile) */

        DisjointSets sets = new DisjointSets(g.getNbNodes());
        ArrayList<Edge> edges = g.listOfEdgesSorted();
        WGraph mst = new WGraph();

        for (int i = 0; i < edges.size(); i++) {
            if (IsSafe(sets, edges.get(i))) { 
                mst.addEdge(edges.get(i)); 
                sets.union(edges.get(i).nodes[0], edges.get(i).nodes[1]);
            }
        }
        return mst;
    }

    public static Boolean IsSafe(DisjointSets p, Edge e) {

        /* Fill this method (The statement return 0 is here only to compile) */
        int responseSet1 = p.find(e.nodes[0]);
        int responseSet2 = p.find(e.nodes[1]);
        if (responseSet1 == responseSet2)
            return false;
        return true;

    }

    public static void main(String[] args) {

        String file = args[0];
        WGraph g = new WGraph(file);
        WGraph t = kruskal(g);
        System.out.println(t);

    }
}
